# CampusConnect Practice
Student Event & Resource Management Portal implementing JWT/bcrypt authentication, Admin/Student roles, event CRUD, event registration/unregistration, seat availability, resource upload/download metadata, dashboard statistics, search, and pagination.

Run backend: `cd backend && npm install && node server.js`
Run frontend with any static server (e.g. Vite) from `frontend`.
