
import express from "express"; import mongoose from "mongoose"; import cors from "cors"; import bcrypt from "bcryptjs"; import jwt from "jsonwebtoken"; import multer from "multer";
const app=express(); app.use(cors()); app.use(express.json()); app.use("/uploads",express.static("uploads"));
const secret="practice-secret";
const userSchema=new mongoose.Schema({name:String,email:{type:String,unique:true},passwordHash:String,role:{type:String,enum:["ADMIN","STUDENT"],default:"STUDENT"}});
const eventSchema=new mongoose.Schema({name:String,date:Date,category:String,description:String,seats:{type:Number,default:50},registrations:[String]});
const resourceSchema=new mongoose.Schema({title:String,subject:String,semester:String,file:String});
const User=mongoose.model("User",userSchema),Event=mongoose.model("Event",eventSchema),Resource=mongoose.model("Resource",resourceSchema);
function auth(req,res,next){try{req.user=jwt.verify(req.headers.authorization?.split(" ")[1],secret);next()}catch{res.status(401).json({message:"Login required"})}}
function admin(req,res,next){if(req.user.role!=="ADMIN")return res.status(403).json({message:"Admin only"});next()}
app.post("/api/auth/register",async(req,res)=>{const {name,email,password,role="STUDENT"}=req.body;if(!name||!email||!password)return res.status(400).json({message:"All fields required"});const u=await User.create({name,email,passwordHash:await bcrypt.hash(password,10),role});res.status(201).json({id:u._id})});
app.post("/api/auth/login",async(req,res)=>{const u=await User.findOne({email:req.body.email});if(!u||!(await bcrypt.compare(req.body.password,u.passwordHash)))return res.status(401).json({message:"Invalid credentials"});res.json({token:jwt.sign({id:u._id,role:u.role,name:u.name},secret,{expiresIn:"1h"}),user:{name:u.name,role:u.role}})});
app.get("/api/events",auth,async(req,res)=>{const {search="",page=1}=req.query;const filter=search?{name:{$regex:search,$options:"i"}}:{};res.json(await Event.find(filter).sort({date:1}).skip((page-1)*10).limit(10))});
app.post("/api/events",auth,admin,async(req,res)=>res.status(201).json(await Event.create(req.body)));
app.put("/api/events/:id",auth,admin,async(req,res)=>res.json(await Event.findByIdAndUpdate(req.params.id,req.body,{new:true})));
app.delete("/api/events/:id",auth,admin,async(req,res)=>{await Event.findByIdAndDelete(req.params.id);res.sendStatus(204)});
app.post("/api/events/:id/register",auth,async(req,res)=>{const e=await Event.findById(req.params.id);if(!e)return res.sendStatus(404);if(e.registrations.length>=e.seats)return res.status(409).json({message:"No seats"});if(!e.registrations.includes(req.user.id))e.registrations.push(req.user.id);await e.save();res.json({message:"Registered",remaining:e.seats-e.registrations.length})});
app.post("/api/events/:id/unregister",auth,async(req,res)=>{const e=await Event.findById(req.params.id);e.registrations=e.registrations.filter(x=>x!==req.user.id);await e.save();res.json({message:"Unregistered"})});
const upload=multer({dest:"uploads/"}); app.post("/api/resources",auth,admin,upload.single("file"),async(req,res)=>res.status(201).json(await Resource.create({title:req.body.title,subject:req.body.subject,semester:req.body.semester,file:req.file?.filename})));
app.get("/api/resources",auth,async(req,res)=>res.json(await Resource.find().sort({title:1}).skip((req.query.page-1||0)*10).limit(10)));
app.get("/api/admin/stats",auth,admin,async(req,res)=>res.json({events:await Event.countDocuments(),registrations:(await Event.find()).reduce((n,e)=>n+e.registrations.length,0)}));
mongoose.connect(process.env.MONGO_URI||"mongodb://localhost:27017/campusconnect_practice").then(()=>app.listen(5001,()=>console.log("API on 5001")));
