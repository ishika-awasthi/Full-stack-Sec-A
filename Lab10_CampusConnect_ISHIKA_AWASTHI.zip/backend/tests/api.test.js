
import request from "supertest";
import {app} from "../src/server.js";
test("health endpoint",async()=>{const r=await request(app).get("/health");expect(r.statusCode).toBe(200);expect(r.body.status).toBe("ok")});
test("protected events route rejects missing token",async()=>{const r=await request(app).get("/api/events");expect(r.statusCode).toBe(401)});
test("protected event creation rejects missing token",async()=>{const r=await request(app).post("/api/events").send({title:"x"});expect(r.statusCode).toBe(401)});
test("login validation rejects empty request",async()=>{const r=await request(app).post("/api/auth/login").send({});expect(r.statusCode).toBe(400)});
test("invalid refresh token rejected",async()=>{const r=await request(app).post("/api/auth/refresh").set("Cookie","refreshToken=bad");expect(r.statusCode).toBe(401)});
