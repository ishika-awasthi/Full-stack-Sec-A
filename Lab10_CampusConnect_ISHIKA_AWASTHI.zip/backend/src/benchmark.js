
import "dotenv/config";
const base=process.env.API_URL||"http://localhost:5000";
const token=process.env.BENCHMARK_TOKEN;
const times=[];
for(let i=0;i<100;i++){const s=performance.now();await fetch(`${base}/api/events`,{headers:{Authorization:`Bearer ${token}`}});times.push(performance.now()-s)}
console.log("Requests:",times.length,"Average:",(times.reduce((a,b)=>a+b,0)/times.length).toFixed(2),"ms");
