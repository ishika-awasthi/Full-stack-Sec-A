
import "dotenv/config";
import express from "express";
import mongoose from "mongoose";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import cookieParser from "cookie-parser";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import { body, validationResult } from "express-validator";
import { createServer } from "http";
import { Server } from "socket.io";
import { createClient } from "redis";

const app=express(), httpServer=createServer(app);
const io=new Server(httpServer,{cors:{origin:process.env.FRONTEND_ORIGIN||"http://localhost:5173",credentials:true}});
app.use(helmet()); app.use(cors({origin:process.env.FRONTEND_ORIGIN||"http://localhost:5173",credentials:true}));
app.use(express.json()); app.use(cookieParser());
const loginLimiter=rateLimit({windowMs:15*60*1000,max:5,standardHeaders:true,legacyHeaders:false});
const userSchema=new mongoose.Schema({name:String,email:{type:String,unique:true},passwordHash:String,role:{type:String,enum:["ADMIN","STUDENT"],default:"STUDENT"}},{timestamps:true});
const eventSchema=new mongoose.Schema({title:String,description:String,date:Date,category:String,seats:{type:Number,default:50},registrations:[{type:mongoose.Schema.Types.ObjectId,ref:"User"}]},{timestamps:true});
const announcementSchema=new mongoose.Schema({title:String,message:String},{timestamps:true});
const User=mongoose.model("User",userSchema), Event=mongoose.model("Event",eventSchema), Announcement=mongoose.model("Announcement",announcementSchema);

const redis=createClient({url:process.env.REDIS_URL||"redis://localhost:6379"});
redis.on("error",e=>console.error("Redis:",e.message));

function signAccess(u){return jwt.sign({id:u._id.toString(),role:u.role,name:u.name},process.env.JWT_SECRET||"devsecret",{expiresIn:"15m"});}
function signRefresh(u){return jwt.sign({id:u._id.toString()},process.env.JWT_REFRESH_SECRET||"devrefresh",{expiresIn:"7d"});}
function authenticate(req,res,next){const h=req.headers.authorization;if(!h?.startsWith("Bearer "))return res.status(401).json({message:"Authentication required"});try{req.user=jwt.verify(h.slice(7),process.env.JWT_SECRET||"devsecret");next()}catch{return res.status(401).json({message:"Invalid or expired token"})}}
function authorize(...roles){return (req,res,next)=>roles.includes(req.user.role)?next():res.status(403).json({message:"Forbidden"})}
function validate(req,res,next){const e=validationResult(req);if(!e.isEmpty())return res.status(400).json({errors:e.array()});next()}

app.post("/api/auth/register",
 body("name").trim().notEmpty(),body("email").isEmail().normalizeEmail(),body("password").isLength({min:8}),body("role").optional().isIn(["ADMIN","STUDENT"]),validate,
 async(req,res)=>{try{const {name,email,password,role="STUDENT"}=req.body;if(await User.findOne({email}))return res.status(409).json({message:"Email already registered"});const passwordHash=await bcrypt.hash(password,12);const u=await User.create({name,email,passwordHash,role});res.status(201).json({message:"Registered",user:{id:u._id,name:u.name,email:u.email,role:u.role}})}catch(e){res.status(500).json({message:e.message})}});

app.post("/api/auth/login",loginLimiter,body("email").isEmail(),body("password").notEmpty(),validate,
 async(req,res)=>{const u=await User.findOne({email:req.body.email});if(!u||!(await bcrypt.compare(req.body.password,u.passwordHash)))return res.status(401).json({message:"Invalid credentials"});res.cookie("refreshToken",signRefresh(u),{httpOnly:true,secure:false,sameSite:"lax",maxAge:7*24*60*60*1000});res.json({accessToken:signAccess(u),user:{id:u._id,name:u.name,email:u.email,role:u.role}})});

app.post("/api/auth/refresh",async(req,res)=>{try{const p=jwt.verify(req.cookies.refreshToken,process.env.JWT_REFRESH_SECRET||"devrefresh");const u=await User.findById(p.id);if(!u)throw Error();res.json({accessToken:signAccess(u)})}catch{res.status(401).json({message:"Invalid refresh token"})}});
app.post("/api/auth/logout",(req,res)=>{res.clearCookie("refreshToken");res.json({message:"Logged out"})});

app.get("/api/events",authenticate,async(req,res)=>{try{const key=`events:${req.query.page||1}:${req.query.search||""}`;const cached=await redis.get(key);if(cached)return res.json({source:"cache",events:JSON.parse(cached)});const page=Math.max(1,Number(req.query.page)||1),limit=10,filter=req.query.search?{title:{$regex:req.query.search,$options:"i"}}:{};const events=await Event.find(filter).sort({date:1}).skip((page-1)*limit).limit(limit);await redis.setEx(key,60,JSON.stringify(events));res.json({source:"database",events})}catch(e){res.status(500).json({message:e.message})}});
async function invalidate(){for(const k of await redis.keys("events:*"))await redis.del(k)}
app.post("/api/events",authenticate,authorize("ADMIN"),body("title").trim().notEmpty(),body("date").isISO8601(),body("seats").isInt({min:1}),validate,async(req,res)=>{const e=await Event.create(req.body);await invalidate();res.status(201).json(e)});
app.put("/api/events/:id",authenticate,authorize("ADMIN"),async(req,res)=>{const e=await Event.findByIdAndUpdate(req.params.id,req.body,{new:true});if(!e)return res.sendStatus(404);await invalidate();res.json(e)});
app.delete("/api/events/:id",authenticate,authorize("ADMIN"),async(req,res)=>{await Event.findByIdAndDelete(req.params.id);await invalidate();res.sendStatus(204)});
app.post("/api/events/:id/rsvp",authenticate,authorize("STUDENT"),async(req,res)=>{const e=await Event.findById(req.params.id);if(!e)return res.sendStatus(404);if(e.registrations.includes(req.user.id))return res.status(409).json({message:"Already registered"});if(e.registrations.length>=e.seats)return res.status(409).json({message:"Event full"});e.registrations.push(req.user.id);await e.save();await invalidate();res.json({message:"RSVP successful"})});
app.post("/api/announcements",authenticate,authorize("ADMIN"),async(req,res)=>{const a=await Announcement.create(req.body);io.to("students").emit("new-announcement",a);res.status(201).json(a)});
app.get("/api/me",authenticate,(req,res)=>res.json({user:req.user}));

io.use((socket,next)=>{try{socket.user=jwt.verify(socket.handshake.auth?.token,process.env.JWT_SECRET||"devsecret");next()}catch{next(new Error("Unauthorized"))}});
io.on("connection",socket=>{if(socket.user.role==="STUDENT")socket.join("students");});

app.get("/health",(req,res)=>res.json({status:"ok"}));

async function start(){await mongoose.connect(process.env.MONGO_URI||"mongodb://localhost:27017/campusconnect");try{await redis.connect()}catch(e){console.warn("Redis unavailable; start Redis for caching.")}const port=process.env.PORT||5000;httpServer.listen(port,()=>console.log(`Backend running on ${port}`))}
if(process.env.NODE_ENV!=="test")start().catch(console.error);
export {app,User,Event};
