# Lab 10 — CampusConnect
Implements the Lab Sheet 10 requirements: JWT/RBAC, bcrypt, refresh cookie, Socket.io notifications, Redis 60-second event caching and invalidation, rate limiting, validation, CORS, Helmet, React state, Docker Compose and tests.

## Run
1. Copy `backend/.env.example` to `backend/.env`.
2. `cd backend && npm install`
3. `cd ../frontend && npm install`
4. Start MongoDB and Redis locally, or use `docker compose up --build`.
5. Frontend: http://localhost:5173
6. Backend: http://localhost:5000

Admin registration can be tested with `"role":"ADMIN"` in a controlled lab environment.
